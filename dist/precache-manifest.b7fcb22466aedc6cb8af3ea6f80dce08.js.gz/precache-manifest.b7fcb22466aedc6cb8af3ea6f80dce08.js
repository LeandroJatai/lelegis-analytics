self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9f288cdbd36802f68746",
    "url": "/static/css/app.d9b5cdec.css"
  },
  {
    "revision": "b834cec756cf1067bb8d",
    "url": "/static/css/chunk-8d2401a4.ead30f8c.css"
  },
  {
    "revision": "03648d4fda20aee3e842",
    "url": "/static/css/chunk-c67402d6.14efb0b1.css"
  },
  {
    "revision": "175bd278b9eff822ebb3",
    "url": "/static/css/chunk-cbb2cb14.3bc6eea5.css"
  },
  {
    "revision": "43e4cd640321be1587a6",
    "url": "/static/css/chunk-vendors.8626a36c.css"
  },
  {
    "revision": "8300bd7f30e0a313c1d772b49d96cb8e",
    "url": "/static/fonts/fa-brands-400.8300bd7f.ttf"
  },
  {
    "revision": "ad527cc5ec23d6da66e8a1d6772ea6d3",
    "url": "/static/fonts/fa-brands-400.ad527cc5.woff"
  },
  {
    "revision": "e2ca6541bff3a3e9f4799ee327b28c58",
    "url": "/static/fonts/fa-brands-400.e2ca6541.eot"
  },
  {
    "revision": "f075c50f89795e4cdb4d45b51f1a6800",
    "url": "/static/fonts/fa-brands-400.f075c50f.woff2"
  },
  {
    "revision": "3c6879c4f342203d099bdd66dce6d396",
    "url": "/static/fonts/fa-regular-400.3c6879c4.woff"
  },
  {
    "revision": "49f00693b0e5d45097832ef5ea1bc541",
    "url": "/static/fonts/fa-regular-400.49f00693.ttf"
  },
  {
    "revision": "4a74738e7728e93c4394b8604081da62",
    "url": "/static/fonts/fa-regular-400.4a74738e.woff2"
  },
  {
    "revision": "b01516c1808be557667befec76cd6318",
    "url": "/static/fonts/fa-regular-400.b01516c1.eot"
  },
  {
    "revision": "205f07b3883c484f27f40d21a92950d4",
    "url": "/static/fonts/fa-solid-900.205f07b3.ttf"
  },
  {
    "revision": "4451e1d86df7491dd874f2c41eee1053",
    "url": "/static/fonts/fa-solid-900.4451e1d8.woff"
  },
  {
    "revision": "8ac3167427b1d5d2967646bd8f7a0587",
    "url": "/static/fonts/fa-solid-900.8ac31674.eot"
  },
  {
    "revision": "8e1ed89b6ccb8ce41faf5cb672677105",
    "url": "/static/fonts/fa-solid-900.8e1ed89b.woff2"
  },
  {
    "revision": "2f12242375edd68e9013ecfb59c672e9",
    "url": "/static/img/fa-brands-400.2f122423.svg"
  },
  {
    "revision": "3602b7e8b2cb1462b0bef9738757ef8a",
    "url": "/static/img/fa-regular-400.3602b7e8.svg"
  },
  {
    "revision": "664de3932dd6291b4b8a8c0ddbcb4c61",
    "url": "/static/img/fa-solid-900.664de393.svg"
  },
  {
    "revision": "ba12e35372ec1c98de50e05f6d85d343",
    "url": "/static/img/logo.ba12e353.svg"
  },
  {
    "revision": "01ba771a768e1b850aa47068e9a4f71f",
    "url": "/static/index.html"
  },
  {
    "revision": "9f288cdbd36802f68746",
    "url": "/static/js/app.4df24bd3.js"
  },
  {
    "revision": "b834cec756cf1067bb8d",
    "url": "/static/js/chunk-8d2401a4.712bfeb2.js"
  },
  {
    "revision": "03648d4fda20aee3e842",
    "url": "/static/js/chunk-c67402d6.67fe00d7.js"
  },
  {
    "revision": "175bd278b9eff822ebb3",
    "url": "/static/js/chunk-cbb2cb14.3e2895a7.js"
  },
  {
    "revision": "43e4cd640321be1587a6",
    "url": "/static/js/chunk-vendors.f7cf3249.js"
  },
  {
    "revision": "f10b2ec4703a7d8c141758354443ae40",
    "url": "/static/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/static/robots.txt"
  },
  {
    "revision": "417103c63218d7d23f9228c0ba0e768f",
    "url": "/static/service-worker.js"
  }
]);